#!/bin/bash


echo '---------------------------------- original file backup'

sudo cp /edx/app/edxapp/edx-platform/lms/envs/common.py /edx/app/edxapp/edx-platform/lms/envs/org_common.py
sudo cp /edx/app/edxapp/edx-platform/lms/urls.py /edx/app/edxapp/edx-platform/lms/org_urls.py
sudo cp -r /edx/app/edxapp/edx-platform/lms/djangoapps /edx/app/edxapp/edx-platform/lms/org_djangoapps
sudo cp -r /edx/app/edxapp/themes/my-theme /edx/app/edxapp/themes/org_my-theme


echo '---------------------------------- repository create app'

sudo su -s /bin/bash edxapp
cd /edx/app/edxapp/edx-platform/lms/djangoapps
/edx/bin/python.edxapp ../../manage.py lms --settings aws startapp repository

exit

echo '---------------------------------- add properties'

sudo chmod -R 777 /edx/app/edxapp/edx-platform/lms
sudo sed -e 's,\(INSTALLED_APPS = (\),\1\n''\ ''\ ''\ ''\ '\''repository'\''\,'',g' /edx/app/edxapp/edx-platform/lms/envs/common.py > /edx/app/edxapp/edx-platform/lms/envs/com_t.py
sudo mv /edx/app/edxapp/edx-platform/lms/envs/com_t.py  /edx/app/edxapp/edx-platform/lms/envs/common.py 
sudo chmod 777 /edx/app/edxapp/edx-platform/lms/envs/common.py 


echo '---------------------------------- add properties in urls.py'

sudo chmod -R 777 /edx/app/edxapp/edx-platform/lms
sudo sed 's,\(notice_detail")\,\),\1\n''\ ''\ ''\ ''\ ''url(r'\''\^repository_list$'\''\, '\''repository.views.list'\''\, name="repository_list")\,\n'\ ''\ ''\ ''\ 'url(r'\''\^repository_detail$'\''\, '\''repository.views.detail'\''\, name="repository_detail")\,\n''\ ''\ ''\ ''\ ''url(r'\''\^customApi/checkPopup$'\''\, '\''notice.views.checkPopup'\''\, name="checkpopup")\,\n'',g' /edx/app/edxapp/edx-platform/lms/urls.py > /edx/app/edxapp/edx-platform/lms/urls_t.py
sudo mv /edx/app/edxapp/edx-platform/lms/urls_t.py /edx/app/edxapp/edx-platform/lms/urls.py 
sudo chmod 777 /edx/app/edxapp/edx-platform/lms/urls.py 


echo '------------------------------------- overwrite folder'

sudo cp -rf ./apps/notice/ /edx/app/edxapp/edx-platform/lms/djangoapps/
sudo cp -rf ./apps/repository /edx/app/edxapp/edx-platform/lms/djangoapps/ 


echo '------------------------------------- migration'

sudo su -s /bin/bash edxapp
cd /edx/app/edxapp/edx-platform
/edx/bin/python.edxapp ./manage.py lms --settings aws makemigrations notice
/edx/bin/python.edxapp ./manage.py lms --settings aws migrate notice

/edx/bin/python.edxapp ./manage.py lms --settings aws makemigrations repository
/edx/bin/python.edxapp ./manage.py lms --settings aws migrate repository

exit
echo '------------------------------------- overwrite folder'

sudo cp -rf ./template/notice /edx/app/edxapp/themes/my-theme/lms/template/
sudo cp -rf ./template/repository /edx/app/edxapp/themes/my-theme/lms/template/
sudo cp -rf ./popup.html /edx/app/edxapp/themes/my-theme/lms/template/

echo '------------------------------------- include popup html in index.html'


sudo chmod -R 777 /edx/app/edxapp/themes/my-theme/lms/templates
echo '<%include file="popup.html" />' >> /edx/app/edxapp/themes/my-theme/lms/templates/index.html


echo '------------------------------------- restart edxapp'

/edx/bin/supervisorctl restart edxapp:lms



