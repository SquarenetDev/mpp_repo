#!/bin/bash


theme_name="$1"
echo $theme_name

echo '---------------------------------- original file backup'

sudo cp /edx/app/edxapp/edx-platform/lms/envs/common.py /edx/app/edxapp/edx-platform/lms/envs/org_common.py
sudo cp /edx/app/edxapp/edx-platform/lms/urls.py /edx/app/edxapp/edx-platform/lms/org_urls.py
sudo cp -r /edx/app/edxapp/edx-platform/lms/djangoapps /edx/app/edxapp/edx-platform/lms/org_djangoapps
sudo cp -r /edx/app/edxapp/themes/$theme_name /edx/app/edxapp/themes/org_$theme_name





echo '------------------------------------- overwrite folder'

sudo cp -rf ./apps/notice/ /edx/app/edxapp/edx-platform/lms/djangoapps/
sudo cp -rf ./apps/repository /edx/app/edxapp/edx-platform/lms/djangoapps/





echo '------------------------------------- overwrite folder'

sudo cp -rf ./template/notice /edx/app/edxapp/themes/my-theme/lms/template/
sudo cp -rf ./template/repository /edx/app/edxapp/themes/my-theme/lms/template/
sudo cp -rf ./popup.html /edx/app/edxapp/themes/my-theme/lms/template/

